package team.woo.controller;

import org.springframework.ui.Model;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import team.woo.domain.ScheduleService;
import team.woo.dto.CalendarDTO;
import team.woo.session.SessionManager;

@Slf4j
@Controller
@RequiredArgsConstructor
public class CalendarController {

    private final SessionManager sessionManager;
    private final ScheduleService scheduleService;

    @PostMapping("/calendar")
    @ResponseBody
    public String saveSelectedDates(@RequestBody CalendarDTO calendarDTO, HttpServletRequest request) {
        HttpSession session = request.getSession();

        // 세션에서 멤버 ID 가져오기
        Long memberId = (Long) session.getAttribute("memberId");

        // 세션에서 scheduleId 가져오기
        Long scheduleId = (Long) session.getAttribute("scheduleId");
        if (scheduleId == null) {
            throw new IllegalArgumentException("Schedule ID not found in session.");
        }

        // CalendarDTO와 scheduleId를 ScheduleService로 전달하여 저장
        scheduleService.saveScheduleFromCalendarDTO(calendarDTO, scheduleId, memberId);

        // 세션에 CalendarDTO 저장
        session.setAttribute("calendarDTO", calendarDTO);

        log.info("Selected Dates and Schedule saved: {}", calendarDTO);

        return "저장 완료";
    }

    @GetMapping("/calendar")
    public String showCalendar(HttpServletRequest request, Model model) {
        // 세션에서 CalendarDTO 가져오기
        CalendarDTO calendarDTO = (CalendarDTO) sessionManager.getSession(request, "calendarDTO");

        if (calendarDTO == null) {
            calendarDTO = new CalendarDTO(); // 기본값으로 초기화
        }

        model.addAttribute("calendarDTO", calendarDTO);
        return "calendar";
    }
}