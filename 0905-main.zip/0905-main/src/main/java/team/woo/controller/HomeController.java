package team.woo.controller;

import jakarta.servlet.http.HttpServletRequest;  // HttpServletRequest import
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;  // Model import
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import team.woo.domain.Schedule;
import team.woo.domain.ScheduleRepository;
import team.woo.domain.ScheduleService;
import team.woo.member.Member;
import team.woo.member.MemberRepository;
import team.woo.session.SessionManager;

import java.util.List;


@Controller
@RequiredArgsConstructor
public class HomeController {

    private final ScheduleRepository scheduleRepository;
    private final MemberRepository memberRepository;
    private final ScheduleService scheduleService;
    private static final Logger logger = LoggerFactory.getLogger(ScheduleController.class);
    private final SessionManager sessionManager;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("pageTitle", "메인 페이지 입니다.");
        return "index";
    }

    @GetMapping("/cabinet")
    public String cabinet(Model model, HttpServletRequest request) {
        Long memberId = (Long) request.getSession().getAttribute("memberId");
        List<Schedule> schedules = (memberId != null) ? scheduleService.getSchedulesByMemberId(memberId) : List.of();
        model.addAttribute("schedules", schedules);
        return "/cabinet";
    }

    @GetMapping("/check")
    public String check(Model model) {
        model.addAttribute("pageTitle", "Check 페이지 입니다.");
        return "check";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("pageTitle", "About 페이지 입니다.");
        return "about";
    }

    @GetMapping("/result_ts/{id}")
    public String resultTs(@PathVariable Long id, Model model, HttpServletRequest request) {
        Schedule schedule = scheduleService.getSchedule(id);
        model.addAttribute("schedule", schedule);
        model.addAttribute("adjustDays", schedule.getAdjustDays());
        model.addAttribute("adjustTime", schedule.getAdjustTime());

        // 세션에서 "member" 키로 사용자 정보를 가져옴
        Member loginMember = (Member) sessionManager.getSession(request, "member");
        if (loginMember == null) {
            logger.warn("세션에 LOGIN_MEMBER 정보가 없음.");
            return "redirect:/login";
        }

        model.addAttribute("loginMember", loginMember);
        logger.info("세션 확인: 사용자 ID = {}", loginMember.getId());

        return "result_ts";
    }

    @GetMapping("/calendarCheck/{loginId}/{id}")
    public String calendarCheck(@PathVariable String loginId, @PathVariable Long id, Model model) {
        Schedule schedule = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid schedule Id: " + id));

        model.addAttribute("adjustDays", schedule.getAdjustDays());
        model.addAttribute("adjustTime", schedule.getAdjustTime());
        model.addAttribute("startTime", schedule.getStartTime());
        model.addAttribute("deadLine", schedule.getDeadLine());
        model.addAttribute("id", id);
        model.addAttribute("scheduleName", schedule.getName());

        return "calendarCheck";
    }
}